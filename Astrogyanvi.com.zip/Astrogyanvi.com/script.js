// =======navbar=======
const mobileMenuBtn = document.querySelector('.mobile-menu-btn-pro');
const mobileMenu = document.querySelector('.mobile-menu-pro');
const menuIcon = document.querySelector('.menu-icon');

mobileMenuBtn.addEventListener('click', () => {
    const isOpen = mobileMenu.classList.toggle('active');
    
    if (isOpen) {
        menuIcon.innerHTML = '<line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line>';
    } else {
        menuIcon.innerHTML = '<line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/>';
    }
});







        //=========silder============
        let index = 0;
        const slides = document.querySelectorAll(".slide");
        const totalSlides = slides.length;
        
        function moveSlide(step) {
            index += step;
            if (index < 0) index = totalSlides - 1;
            if (index >= totalSlides) index = 0;
            document.querySelector(".carousel").style.transform = `translateX(-${index * 100}%)`;
        }
        
        // Automatically move to the next slide every 3 seconds (3000 milliseconds)
        setInterval(() => {
            moveSlide(1);
        }, 2000);






        
        // Reveal animation on scroll
        document.addEventListener('DOMContentLoaded', function() {
            // Initial check for elements in viewport
            revealElements();
            
            // Check on scroll
            window.addEventListener('scroll', revealElements);
            
            function revealElements() {
                const reveals = document.querySelectorAll('.reveal');
                
                for (let i = 0; i < reveals.length; i++) {
                    const windowHeight = window.innerHeight;
                    const elementTop = reveals[i].getBoundingClientRect().top;
                    const elementVisible = 150;
                    
                    if (elementTop < windowHeight - elementVisible) {
                        reveals[i].classList.add('active');
                    }
                }
            }
            
            // Add staggered delay to each card for better animation
            const cards = document.querySelectorAll('.step-card');
            cards.forEach((card, index) => {
                card.style.transitionDelay = `${index * 0.2}s`;
            });
        });




        document.addEventListener('DOMContentLoaded', function() {
            // Animate stats counter
            function animateCounter() {
                const counters = document.querySelectorAll('.counter');
                const speed = 200; // The lower the faster
                
                counters.forEach(counter => {
                    const target = +counter.getAttribute('data-count');
                    let count = 0;
                    
                    const updateCount = () => {
                        const increment = target / speed;
                        
                        if (count < target) {
                            count += increment;
                            counter.innerText = Math.ceil(count);
                            setTimeout(updateCount, 1);
                        } else {
                            counter.innerText = target;
                        }
                    };
                    
                    updateCount();
                });
            }
            
            // Fade in animation for cards
            function revealElements() {
                const elements = document.querySelectorAll('.fade-in-up');
                
                elements.forEach((element, index) => {
                    // Add staggered delay
                    element.style.transitionDelay = `${index * 0.2}s`;
                    
                    const windowHeight = window.innerHeight;
                    const elementTop = element.getBoundingClientRect().top;
                    const elementVisible = 150;
                    
                    if (elementTop < windowHeight - elementVisible) {
                        element.classList.add('active');
                        
                        // Start counter animation when cards become visible
                        if (index === 0) {
                            setTimeout(animateCounter, 500);
                        }
                    }
                });
            }
            
            // Check on load and scroll
            revealElements();
            window.addEventListener('scroll', revealElements);
            
            // Create additional stars for cosmic background
            function createStars() {
                const cosmicBg = document.getElementById('cosmicBg');
                const starsCount = 100;
                
                for (let i = 0; i < starsCount; i++) {
                    const star = document.createElement('div');
                    star.classList.add('star');
                    
                    // Random position
                    const posX = Math.random() * 100;
                    const posY = Math.random() * 100;
                    
                    // Random size
                    const size = Math.random() * 2;
                    
                    // Random opacity
                    const opacity = Math.random() * 0.8 + 0.2;
                    
                    // Random animation delay
                    const delay = Math.random() * 5;
                    
                    star.style.cssText = `
                        position: absolute;
                        top: ${posY}%;
                        left: ${posX}%;
                        width: ${size}px;
                        height: ${size}px;
                        background-color: white;
                        border-radius: 50%;
                        opacity: ${opacity};
                        animation: twinkle 5s ease-in-out infinite alternate;
                        animation-delay: ${delay}s;
                    `;
                    
                    cosmicBg.appendChild(star);
                }
            }
            
            createStars();
        });




        // <!-- =====astrologers section===== -->



  

        document.addEventListener('DOMContentLoaded', function() {
            // Initialize Swiper
            const swiper = new Swiper('.swiper', {
                // Optional parameters
                loop: true,
                grabCursor: true,
                centeredSlides: false,
                autoplay: {
                    delay: 3000,
                    disableOnInteraction: false,
                },
                
                // Responsive breakpoints
                breakpoints: {
                    // when window width is >= 320px
                    320: {
                        slidesPerView: 1,
                        spaceBetween: 20
                    },
                    // when window width is >= 480px
                    480: {
                        slidesPerView: 1,
                        spaceBetween: 20
                    },
                    // when window width is >= 768px
                    768: {
                        slidesPerView: 2,
                        spaceBetween: 30
                    },
                    // when window width is >= 1024px
                    1024: {
                        slidesPerView: 3,
                        spaceBetween: 30
                    }
                },
                
                // If we need pagination
                pagination: {
                    el: '.swiper-pagination-pro',
                    clickable: true,
                },
                
                // Navigation arrows
                navigation: {
                    nextEl: '.swiper-button-next',
                    prevEl: '.swiper-button-prev',
                },
            });
        });
        

        

        
        const swiper = new Swiper('.blog-swiper', {
            slidesPerView: 1,
            spaceBetween: 30,
            loop: true,
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            autoplay: {
                delay: 3000,
                disableOnInteraction: false,
            },
       
                // Responsive breakpoints
                breakpoints: {
                    // when window width is >= 320px
                    320: {
                        slidesPerView: 1,
                        spaceBetween: 20
                    },
                    // when window width is >= 480px
                    480: {
                        slidesPerView: 1,
                        spaceBetween: 20
                    },
                    // when window width is >= 768px
                    768: {
                        slidesPerView: 2,
                        spaceBetween: 30
                    },
                    // when window width is >= 1024px
                    1024: {
                        slidesPerView: 3,
                        spaceBetween: 30
                    }
                }
        });


        


// ==========loader==========
window.addEventListener('load', function() {
    const loader = document.getElementById('loader');
    loader.style.display = 'none';
  });
  // ==========loader-end==========
  
  

  

      // Scroll to top functionality
      function setupScrollTopButton() {
        const scrollTopBtn = document.getElementById('scrollTopBtn');
        
        // Show/hide button based on scroll position
        window.addEventListener('scroll', () => {
            if (window.pageYOffset > 300) {
                scrollTopBtn.classList.add('visible');
            } else {
                scrollTopBtn.classList.remove('visible');
            }
        });
        
        // Scroll to top when button is clicked
        scrollTopBtn.addEventListener('click', () => {
            // Smooth scroll to top
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
            
            // Add extra animation to the button when clicked
            scrollTopBtn.style.transform = 'translateY(-10px) scale(0.9)';
            setTimeout(() => {
                scrollTopBtn.style.transform = '';
            }, 300);
        });
    }
    
    // Initialize when DOM is loaded
    document.addEventListener('DOMContentLoaded', () => {
        setupScrollTopButton();
    });








// ==============astrologers-section===============


     // Filter button functionality
     document.getElementById('filter-btn').addEventListener('click', function() {
        // Collect all selected filters
        const selectedFilters = {
            availability: document.querySelector('input[name="availability"]:checked')?.id || null,
            categories: Array.from(document.querySelectorAll('#categoriesDropdown + .dropdown-menu input[type="checkbox"]:checked')).map(el => el.id),
            skills: Array.from(document.querySelectorAll('#skillsDropdown + .dropdown-menu input[type="checkbox"]:checked')).map(el => el.id),
            label: document.querySelector('input[name="label"]:checked')?.id || null,
            search: document.querySelector('.form-control').value
        };
        
        console.log('Applied filters:', selectedFilters);
        // Here you would typically send these filters to your backend or filter your data
        alert('Filters applied! Check console for details.');
    });

    // Reset button functionality
    document.getElementById('reset-btn').addEventListener('click', function() {
        // Reset all form elements
        document.querySelectorAll('input[type="radio"], input[type="checkbox"]').forEach(input => {
            input.checked = false;
        });
        
        document.querySelector('.form-control').value = '';
        
        console.log('All filters reset');
        alert('All filters have been reset!');
    });









    // =======login========


    function showLoginForm() {
        document.getElementById("loginForm").style.display = "block";
    }
    function hideLoginForm() {
        document.getElementById("loginForm").style.display = "none";
    }
    function toggleUser(type) {
        document.querySelectorAll(".toggle-buttons button").forEach(btn => btn.classList.remove("active"));
        document.querySelector(`.toggle-buttons button[onclick="toggleUser('${type}')"]`).classList.add("active");
    }